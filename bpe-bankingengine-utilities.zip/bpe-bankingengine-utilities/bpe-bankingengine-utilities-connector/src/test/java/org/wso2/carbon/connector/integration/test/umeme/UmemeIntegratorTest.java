package org.wso2.carbon.connector.integration.test.umeme;

import com.cestasoft.bankingengine.esb.connector.AbsaUgandaUmemeConnector;
import com.cestasoft.bankingengine.esb.connector.MainUtil;
import org.testng.annotations.Test;
import org.wso2.connector.integration.test.base.ConnectorIntegrationTestBase;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.util.UUID;

public class UmemeIntegratorTest extends ConnectorIntegrationTestBase {
    public static final String ABSA_WSO2_UMEME_PRIV_KEY = "private_key.der";

    public final String REGISTRY = "registry";
    public final String URL_SEPARATOR = "/";

    @Test(enabled = true, groups = {"wso2.ei"}, description = "umeme encryption test case")
    public void testEncryptionDecryption() {
        log.info("Begin testEncryptionDecryption test");
        String privateKeyPath = getRootdir() + URL_SEPARATOR + ABSA_WSO2_UMEME_PRIV_KEY;
        String requestId = String.valueOf(UUID.randomUUID());
        requestId = "1722881601680";

        // we want to decrypt this string and get this result:
        String password = "passport";
        log.debug("PASSWORD ---> " + password);
        log.debug("returnData -->" + requestId);

        String encryptedRequestId = null;
        try {
            encryptedRequestId = MainUtil.encrypt(requestId, privateKeyPath);
        } catch (IOException | NoSuchAlgorithmException | InvalidKeyException | InvalidKeySpecException | SignatureException e) {
            e.printStackTrace();
        }

        log.info("encryptedRequestId>>" + encryptedRequestId);
        log.info("End testEncryptionDecryption test");
    }

    private String getRootdir() {
        String defaultFSRegRoot = getHome().replace(File.separator, URL_SEPARATOR);
        if (!defaultFSRegRoot.endsWith(URL_SEPARATOR)) {
            defaultFSRegRoot = defaultFSRegRoot + URL_SEPARATOR;
        }
        // Default registry root : <CARBON_HOME>/registry/
        defaultFSRegRoot += REGISTRY + URL_SEPARATOR;
        log.debug("defaultFSRegRoot -->" + defaultFSRegRoot);
        return getUri(defaultFSRegRoot);
    }

    private String getHome() {
        return "/Users/nguni52/dev/runtime/vanilla/wso2ei-6.6.0";
    }

    private String getUri(String defaultFSRegRoot) {
        return Paths.get(defaultFSRegRoot + AbsaUgandaUmemeConnector.SUB_FOLDR_PATH).toString();
    }
}
