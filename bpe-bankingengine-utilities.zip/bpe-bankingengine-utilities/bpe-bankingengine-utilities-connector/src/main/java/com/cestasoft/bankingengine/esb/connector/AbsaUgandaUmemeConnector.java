package com.cestasoft.bankingengine.esb.connector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.synapse.MessageContext;
import org.wso2.carbon.connector.core.AbstractConnector;
import org.wso2.carbon.connector.core.ConnectException;

import javax.crypto.Cipher;
import java.io.File;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.util.Base64;

import static org.wso2.carbon.mediation.registry.RegistryHelper.getSystemDependentPath;

public class AbsaUgandaUmemeConnector extends AbstractConnector {
    private static final Log log = LogFactory.getLog(AbsaUgandaUmemeConnector.class);
    public static final String REGISTRY = "registry";
    public static final String URL_SEPARATOR = "/";
    public static final String SUB_FOLDR_PATH = "config/umeme/key";
    private static final String REQUEST_ID = "requestId";
//    private final String keyAlias = "cestaumemeabsaintegration";
//    private final String keyPassword = "AbsaCestaUmeme.2024";
    public static final String ABSA_WSO2_UMEME_PRIV_KEY = "private_key.der";
    private static final String ENCRYPTED_REQUEST_ID = "encryptedRequestId";

    @Override
    public void connect(MessageContext messageContext) throws ConnectException {
        String requestId = (String) messageContext.getProperty(REQUEST_ID);

        try {
            String privateKeyPath = getRootdir() + "/" + ABSA_WSO2_UMEME_PRIV_KEY;
            log.debug("[[AbsaUgandaUmemeConnector]] privateKeyPath: " + privateKeyPath);
            String encryptedRequestId = MainUtil.encrypt(requestId, privateKeyPath);
            messageContext.setProperty(ENCRYPTED_REQUEST_ID, encryptedRequestId);
            log.debug(encryptedRequestId);
        } catch(Exception ex) {
            ex.printStackTrace();
        }
    }

    private String getRootdir() {
        String defaultFSRegRoot = getHome().replace(File.separator, URL_SEPARATOR);
        if (!defaultFSRegRoot.endsWith(URL_SEPARATOR)) {
            defaultFSRegRoot = defaultFSRegRoot + URL_SEPARATOR;
        }
        // Default registry root : <CARBON_HOME>/registry/
        defaultFSRegRoot += REGISTRY + URL_SEPARATOR;
        log.debug("defaultFSRegRoot -->" + defaultFSRegRoot);
        return getUri(defaultFSRegRoot);
    }

    private String getHome() {
        String carbonHome = System.getProperty("carbon.home");
        if (log.isDebugEnabled()) {
            log.debug("carbonHome>>" + carbonHome);
        }
        if (carbonHome == null || "".equals(carbonHome) || ".".equals(carbonHome)) {
            carbonHome = getSystemDependentPath(new File(".").getAbsolutePath());
        }
        return carbonHome;
    }

    private String getUri(String defaultFSRegRoot) {
        return Paths.get(defaultFSRegRoot + AbsaUgandaUmemeConnector.SUB_FOLDR_PATH).toString();
    }
}
