#!/bin/zsh
mvn clean install -DskipTests
cp target/utilities-umeme-connector-1.0.0.zip ../bpe-bankingengine-utilities-connector-exp/
#/Users/nguni52/dev/runtime/vanilla/wso2ei-6.6.0/bin/integrator.sh stop
#/Users/nguni52/dev/runtime/vanilla/wso2ei-6.6.0/bin/integrator.sh start
