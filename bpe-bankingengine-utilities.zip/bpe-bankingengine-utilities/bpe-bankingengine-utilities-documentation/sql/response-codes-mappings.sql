-- umeme.response_codes_mappings definition
-- Drop table
DROP TABLE IF EXISTS response_codes_mappings;
CREATE TABLE response_codes_mappings (
  id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
  status_code integer NOT NULL,
  status_description varchar(99) NOT NULL,
  umeme_code integer NULL,
  date_created timestamptz NULL DEFAULT CURRENT_TIMESTAMP,
  date_modified timestamptz NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);


INSERT INTO response_codes_mappings (status_code, status_description) VALUES (0, 'SUCCESS');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (1, 'INVALID CUSTOMER REFERENCE');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (2, 'INVALID VENDOR CREDENTIALS');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (3, 'INVALID TRANSACTION AMOUNT');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (4, 'INVALID PAYMENT DATE');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (5, 'INVALID TRANSACTION TYPE');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (6, 'INVALID CUSTOMER TELEPHONE');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (7, 'INVALID PAYMENT TYPE');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (8, 'INVALID TELLER REQUIRED');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (9, 'TRANSACTION DETAILS ALREADY RECEIVED');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (10, 'GENERAL ERROR AT UMEME');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (11, 'VENDOR CREDENTIALS HAVE BEEN DEACTIVATED');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (12, 'INVALID PHONE NUMBER');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (13, 'CUSTOMER NAME NOT SUPPLIED');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (14, 'TRANSACTION TYPE NOT SUPPLIED. EG CASH,EFT');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (15, 'PAYMENT TYPE NOT SUPPLIED. EG 2,3,4');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (16, 'VENDOR TRANSACTION REFERENCE NOT SUPPLIED');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (17, 'TELLER DETAILS NOT SUPPLIED');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (18, 'SIGNATURE NOT VALID');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (19, 'SIGNATURE NOT PROVIDED');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (20, 'DUPLICATE VENDOR REFERENCE');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (21, 'SUSPECTED DOUBLE POSTING');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (22, 'ORIGINAL VENDOR TRANSACTION REFERENCE NOT SUPPLIED');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (23, 'TRANSACTION NARATION IS REQUIRED');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (24, 'INVALID ORIGINAL VENDOR TRANSACTION REFERENCE');
INSERT INTO response_codes_mappings (status_code, status_description) VALUES (37, 'CUSTOMER NAME DOES NOT EXIST');
