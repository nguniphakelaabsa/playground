#!/bin/bash
#
sudo yum update -y

sudo yum install openjdk-17-jdk -y

sudo yum install maven -y