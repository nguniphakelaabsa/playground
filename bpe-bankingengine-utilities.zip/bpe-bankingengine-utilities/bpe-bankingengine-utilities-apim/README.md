# README #

This child maven project is for the API to deploy to APIM. Please refer this documentation for more detail: https://srv01cf1/pages/viewpage.action?pageId=622921198


* api.yml contains sample values for creating an API. You must change these values with your API specification.
* swagger.json contains sample API resources for the sample API. You must replace the sample swagger specification as per your API definition.
