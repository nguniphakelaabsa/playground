#!/bin/bash

mvn -B -s ~/.m2/settings.xml clean install -DskipTests && \
# mvn clean deploy
cp bpe-bankingengine-utilities-car/target/bpe-bankingengine-utilities-car_1.0.0.car /Users/nguni52/dev/runtime/vanilla/wso2ei-6.6.0/repository/deployment/server/carbonapps

# GET TOKEN assuming username and password is admin:admin
# TOKEN=$(curl -X GET "https://ec2-54-229-75-236.eu-west-1.compute.amazonaws.com:9164/management/login" -H "accept: application/json" -H "Authorization: Basic YWRtaW46YWRtaW4=" -k | jq -r '.AccessToken')

# # GET current applications
# curl -i -k -X GET -H "Authorization: Bearer $TOKEN" -H "accept: application/json" "https://ec2-54-229-75-236.eu-west-1.compute.amazonaws.com:9164/management/applications"

# # Upload current one
# curl -i -k -X POST -H "Authorization: Bearer $TOKEN" "https://ec2-54-229-75-236.eu-west-1.compute.amazonaws.com:9164/management/applications" --form "file=@bpe-bankingengine-utilities-car/target/bpe-bankingengine-utilities-car_1.0.0.car"