-- umeme.biller_transactions definition
-- Drop table
DROP TABLE IF EXISTS biller_transactions;
CREATE TABLE biller_transactions (
  id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
  transaction_ref varchar(99) NOT NULL,
  phone_number varchar(15) NOT NULL,
  payment_type varchar(99) NOT NULL,
  meter_number varchar(50) NULL,
  customer_type varchar(99) NOT NULL,
  customer_name varchar(99) NOT NULL,
  date_created timestamptz NULL DEFAULT CURRENT_TIMESTAMP,
  date_modified timestamptz NULL DEFAULT CURRENT_TIMESTAMP,
  account_save_amount numeric(15, 2) NULL,
  account_pay_amount numeric(15, 2) NULL,
  debt_recovery numeric(10, 2) NULL,
  tax numeric(10, 2) NULL,
  total_amount numeric(10, 2) NULL,
  units numeric(10, 2) NULL,
  token_value numeric(15, 2) NULL,
  remaining_credit numeric(10, 2) NULL,
  service_fee numeric(10, 2) NULL,
  fx varchar(50) NULL,
  inflation varchar(50) NULL,
  prepaid_token varchar(255) NULL,
  receipt_number varchar(50) NULL,
  life_line varchar(50) NULL,
  fuel numeric(10, 2) NULL,
  bank_transaction_id varchar(50) NULL,
  tariff_description varchar(255) NULL,
  status_code varchar(50) NULL,
  status_description varchar(255) NULL,
  transaction_status varchar(255) NULL,
  retry_count integer NOT NULL DEFAULT 0,
  request_id character varying(99),
  encrypted_request_id character varying(512),
  percentage_debt character varying(99),
  account_balance character varying(99),
  units_payment  character varying(99),
  debt_payment  character varying(99),
  units  character varying(99),
  units_type  character varying(99),
  PRIMARY KEY (transaction_ref)
);

ALTER TABLE IF EXISTS public.biller_transactions
    ADD COLUMN request_id character varying(99),
    ADD COLUMN encrypted_request_id character varying(512);

ALTER TABLE IF EXISTS public.biller_transactions
    ADD COLUMN collection_status character varying(99),
    ADD COLUMN account_balance numeric(10, 2) NULL,
    ADD COLUMN collection_id character varying(99),
    ADD COLUMN confirmation_message character varying(256);

ALTER TABLE IF EXISTS public.biller_transactions
    ALTER COLUMN account_balance TYPE numeric(15, 2),
    ALTER COLUMN total_amount TYPE numeric(15, 2),
    ALTER COLUMN token_value TYPE numeric(15, 2),
    ALTER COLUMN account_save_amount TYPE numeric(15, 2),
    ALTER COLUMN account_pay_amount TYPE numeric(15, 2);
  
ALTER TABLE IF EXISTS public.biller_transactions
    ADD COLUMN percentage_debt character varying(99),
    ADD COLUMN account_balance character varying(99),
    ADD COLUMN units_payment character varying(99),
    ADD COLUMN units_type character varying(99);

ALTER TABLE IF EXISTS public.biller_transactions
    ADD COLUMN account_balance character varying(99);

/*** 03/02/2025
 * Add columns to the biller_transactions table
 */
 ALTER TABLE IF EXISTS public.biller_transactions
    ADD COLUMN debt_payment character varying(99);    

/***********************************************************************************************
 * FIX FOR DUPLICATE TRANSACTIONS COMING FROM UPSTREAM
 ***********************************************************************************************/
export DB_BACKUP_DIR=/opt/backups/db
pg_dump -U postgres -d billers > $DB_BACKUP_DIR/bpe_bankingengine.sql

ALTER TABLE public.biller_transactions
DROP CONSTRAINT IF EXISTS biller_transactions_pkey,
ADD PRIMARY KEY (transaction_ref);

-- REMOVE FROM PROD, duplicate transactions.
delete from  public.biller_transactions
where transaction_ref IN (select transaction_ref from public.biller_transactions group by transaction_ref having count(*) > 1);
