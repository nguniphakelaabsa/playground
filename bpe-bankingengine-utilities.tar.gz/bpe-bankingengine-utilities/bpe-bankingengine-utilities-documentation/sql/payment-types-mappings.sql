-- umeme.payment_types_mappings definition
-- Drop table
DROP TABLE IF EXISTS payment_types_mappings;
CREATE TABLE payment_types_mappings (
  id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
  payment_code integer NOT NULL,
  payment_type varchar(99) NOT NULL,
  date_created timestamptz NULL DEFAULT CURRENT_TIMESTAMP,
  date_modified timestamptz NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);

INSERT INTO payment_types_mappings (payment_code, payment_type) VALUES (0, 'SUCCESS');
INSERT INTO payment_types_mappings (payment_code, payment_type) VALUES (1, 'Security Deposit');
INSERT INTO payment_types_mappings (payment_code, payment_type) VALUES (2, 'Energy Payment');
INSERT INTO payment_types_mappings (payment_code, payment_type) VALUES (3, 'Bounced Cheque Fine');
INSERT INTO payment_types_mappings (payment_code, payment_type) VALUES (4, 'Capital Contribution');
INSERT INTO payment_types_mappings (payment_code, payment_type) VALUES (5, 'Reconnection Fee');
INSERT INTO payment_types_mappings (payment_code, payment_type) VALUES (6, 'Rechargeable Works Order');
INSERT INTO payment_types_mappings (payment_code, payment_type) VALUES (7, 'Meter Test Fee');
INSERT INTO payment_types_mappings (payment_code, payment_type) VALUES (9, 'Fine General');
INSERT INTO payment_types_mappings (payment_code, payment_type) VALUES (10, 'Non Refund Tender Deposit');
INSERT INTO payment_types_mappings (payment_code, payment_type) VALUES (14, 'Inspection Fee');
