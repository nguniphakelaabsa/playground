curl -k -H "Content-Type: application/x-www-form-urlencoded" -d
"grant_type=password&username=username&password=password&scope=token_public
token_private ststoken_public" https://apimpro.umeme.co.ug:7243/token



https://UGPKAMRAPP01133.corp.dsarena.com:8243/utility_bill_payments/api/umeme' 