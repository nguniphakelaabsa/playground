package com.cestasoft.bankingengine.esb.connector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class MainUtil {
    private static final Log log = LogFactory.getLog(MainUtil.class);

    public static String encrypt(String requestId, String privateKeyPath) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException, SignatureException {
        // Read the private key from the file
        byte[] keyBytes = Files.readAllBytes(Paths.get(privateKeyPath));

        // Generate the private key
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        PrivateKey privateKey = kf.generatePrivate(spec);
        log.info(privateKey.getFormat().toString());
        Signature sign;
        sign = Signature.getInstance("SHA256WithRSA"); //initialize to use SHA-256 and RSA
        sign.initSign(privateKey);

        //get request id
        byte[] hash2 = requestId.getBytes(StandardCharsets.UTF_8);
        sign.update(hash2);
        byte[] digitalSignature2 = sign.sign();  //here the function sign() will hash using SHA-256 and encrypt using RSA

        // Encode the encrypted bytes to Base64 for easy handling
//        return  Base64.getEncoder().encodeToString(digitalSignature2);

        String encrypted = Base64.getEncoder().encodeToString(digitalSignature2);
        log.info(encrypted);

        return encrypted;
    }


    public static String encrypt1(String requestId, String privateKeyPath)
            throws KeyStoreException, IOException, CertificateException, NoSuchAlgorithmException,
            UnrecoverableKeyException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException,
            BadPaddingException, InvalidKeySpecException, NoSuchProviderException {
        log.info("[[MainUtil.encrypt]] - REQUEST ID: " + requestId);

//        requestId = "1722881601680";

        // 1. Hash with SHA-256
       MessageDigest digest = MessageDigest.getInstance("SHA-256");
       byte[] hash = digest.digest(requestId.getBytes(StandardCharsets.UTF_8));
//
       String hashedRequestId = bytesToHex(hash);

       log.info("[[MainUtil.encrypt]] - SHA-256 HASHED REQUEST ID: " + hashedRequestId);

       String base64EncodedRequestId = Base64.getEncoder().encodeToString(hashedRequestId.getBytes());

       log.info("[[MainUtil.encrypt]] - Base64 Encoded HASHED REQUEST ID: " + base64EncodedRequestId);


        // String base64EncodedRequestId = Base64.getEncoder().encodeToString(requestId.getBytes());
        // log.info("[[MainUtil.encrypt]] - Base64 Encoded HASHED REQUEST ID: " + base64EncodedRequestId);

        // Load the keystore
//        KeyStore keystore = KeyStore.getInstance("JKS");
//        try (FileInputStream fis = new FileInputStream(keystorePath)) {
//            keystore.load(fis, keyPassword.toCharArray());
//        }
//
//        // Get the private key
//        PrivateKey privateKey = (PrivateKey) keystore.getKey(keyAlias, keyPassword.toCharArray());


        // 2. Encrypt with RSA

        // get keystore from file
        // Read the private key from the file
        byte[] keyBytes = Files.readAllBytes(Paths.get(privateKeyPath));

        // Generate the private key
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        PrivateKey privateKey = kf.generatePrivate(spec);
        log.info(privateKey.getFormat().toString());

        // Initialize the cipher
        Security.addProvider(new BouncyCastleProvider());
        Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding", "BC");
        cipher.init(Cipher.ENCRYPT_MODE, privateKey);

        // Encrypt the plaintext
        byte[] encryptedBytes = cipher.doFinal(hashedRequestId.getBytes(StandardCharsets.UTF_8));

        // Encode the encrypted bytes to Base64 for easy handling
        String encrypted = Base64.getEncoder().encodeToString(encryptedBytes);
        log.info(encrypted);

        return encrypted;
    }

    private static String bytesToHex(byte[] hash) {
        // Convert byte array to hexadecimal string
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }

        return hexString.toString();
    }
}
