openssl pkcs12 -export -in wso2_dev_server_key.pub -inkey wso2_dev_server_private_key -out keystore.p12 -name umeme


openssl pkcs12 -export -out certificate.pfx -inkey wso2_dev_server_private_key -in self_signed_certificate.crt


openssl pkcs8 -topk8 -inform PEM -outform DER -in private_key.pem -out privatekey.der -nocrypt
